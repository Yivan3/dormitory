from django.http import HttpResponse
from django.shortcuts import render

from django.views.decorators.csrf import csrf_exempt
from .models import *
import random


@csrf_exempt
def login_view(request):
    way = request.method
    if way == 'GET':
        return render(request, 'login.html')
    else:
        uname = request.POST.get('username')
        passwd = request.POST.get('password')
        login_type = request.POST.get('login', '')
        if login_type == '学生登录':
            theNumber = Student.objects.filter(Sid=uname, Spassword=passwd).count()
            if theNumber == 0:
                return render(request, 'login.html')
            else:
                data = Student.objects.filter(Sid=uname)
                return render(request, 'theInfo.html', {'data': data})
        elif login_type == '教师登录':
            theNumebr = Manager.objects.filter(Mid=uname, Mpassword=passwd)
            if theNumebr == 0:
                return render(request, 'login.html')
            else:
                data = Manager.objects.filter(Mid=uname, Mpassword=passwd)
                brokenDority = Fix.objects.filter(id=uname)
                building_id = 0
                for i in data:
                    building_id = int(i.building)
                building = (Manager.objects.get(building=building_id)).building
                students = Student.objects.filter(building=building)
                context = {
                    'fix': brokenDority,
                    'data': data,
                    'students': students,
                }
                return render(request, 'managePage.html', context)


@csrf_exempt
def register(request):
    theWay = request.method
    if theWay == 'GET':
        return render(request, 'register.html')
    else:
        username = request.POST.get('username')
        userId = request.POST.get('userid')
        password = request.POST.get('password')
        confirmPassword = request.POST.get('confirmPassword')
        if password != confirmPassword:
            return render(request, 'login.html')
        else:
            building = random.randint(1, 10)
            room = random.randint(1, 10)
            Mid = (Manager.objects.get(building=building)).Mid
            print(Mid, type(Mid))
            student = Student(building=building, room=room, Sname=username, Mid=Mid, Spassword=password, Sid=userId)
            student.save()
            return render(request, 'login.html')


@csrf_exempt
def theInfo(request):
    theWay = request.method
    if theWay == 'GET':
        return render(request, 'theInfo.html')
    else:
        changedPwd = request.POST.get('password')
        advise = request.POST.get('advise')
        building = request.POST.get('building')
        room = request.POST.get('room')
        Sid = request.POST.get('Sid')
        print(building, room, Sid)
        print(changedPwd, advise)
        if changedPwd and advise:
            student = Student.objects.get(Sid=Sid)
            student.Spassword = changedPwd
            student.save()
            fix = Fix(id=Sid, building=building, room=room, advise=advise)
            fix.save()
            print('两个都有')
        elif changedPwd:
            print('改密码')
            student = Student.objects.get(Sid=Sid)
            student.Spassword = changedPwd
            student.save()
        elif advise:
            print('提意见')
            fix = Fix(id=Sid, building=building, room=room, advise=advise)
            fix.save()
        else:
            return render(request, 'login.html')
        return render(request, 'login.html')


@csrf_exempt
def managePage(request):
    theWay = request.method
    if theWay == 'GET':
        return render(request, 'managePage.html')
    else:
        theType = request.POST.get('处理', '')
        if theType == '删除':
            print('执行删除')
            Sid = request.POST.get('userId', '')
            student = Student.objects.get(Sid=Sid)
            theMid = request.POST.get('Mid', '')
            brokenDority = Fix.objects.filter(id=theMid)
            print('*************', theMid)
            data = Manager.objects.filter(Mid=theMid)
            print('*******************删除')
            print(data)
            building_id = 0
            for i in data:
                print(i.building, type(i.building))
                building_id = i.building
            building = (Manager.objects.get(building=building_id)).building
            students = Student.objects.filter(building=building)
            context = {
                'fix': brokenDority,
                'data': data,
                'students': students,
            }
            student.delete()
            return render(request, 'managePage.html', context)
        elif theType == '打分':
            print('执行打分')
            room = request.POST.get('roomId', '')
            point = request.POST.get('point', '')
            theMid = request.POST.get('Mid', '')
            brokenDority = Fix.objects.filter(id=theMid)
            data = Manager.objects.filter(Mid=theMid)
            print('*******************打分')
            print(data)
            building_id = 0
            for i in data:
                print(i.building, type(i.building))
                building_id = i.building
            building = (Manager.objects.get(building=building_id)).building
            students = Student.objects.filter(building=building)
            context = {
                'fix': brokenDority,
                'data': data,
                'students': students,
            }
            students = Student.objects.filter(room=room)  # 查询所有room值为1的Student对象
            for student in students:
                student.point = point  # 将point字段的值设置为1
                student.save()  # 保存更改到数据库
            return render(request, 'managePage.html', context)
        elif theType == '维修':
            theMid = request.POST.get('Mid', '')
            brokenDority = Fix.objects.filter(id=theMid)
            data = Manager.objects.filter(Mid=theMid)
            # 进行删除
            theRoom = request.POST.get('fixed', '')
            matches = Fix.objects.filter(room=theRoom)
            # 删除这些匹配的对象
            for i in matches:
                i.delete()
            print('*******************打分')
            print(data)
            building_id = 0
            for i in data:
                print(i.building, type(i.building))
                building_id = i.building
            building = (Manager.objects.get(building=building_id)).building
            students = Student.objects.filter(building=building)
            context = {
                'fix': brokenDority,
                'data': data,
                'students': students,
            }
            return render(request, 'managePage.html', context)
