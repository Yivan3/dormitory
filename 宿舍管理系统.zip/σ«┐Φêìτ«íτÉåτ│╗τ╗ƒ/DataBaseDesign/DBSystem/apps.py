from django.apps import AppConfig


class DbsystemConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'DBSystem'
