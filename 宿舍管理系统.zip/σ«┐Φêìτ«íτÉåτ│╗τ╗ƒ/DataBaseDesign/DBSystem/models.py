from django.db import models


class Student(models.Model):
    Sname = models.CharField(max_length=100)
    Sid = models.IntegerField(primary_key=True, default=0)  # 设置默认值为1
    building = models.CharField(max_length=100, default='Default Building')
    Spassword = models.CharField(max_length=100, default='1')
    room = models.CharField(max_length=100, default='Default Room')
    point = models.CharField(max_length=100, default=0)
    Mid = models.IntegerField(default=1)  # 设置默认值为1


class Manager(models.Model):
    Mid = models.IntegerField(primary_key=True, default=1)  # 设置默认值为1
    Mname = models.CharField(max_length=100, default='Default Manager Name')
    Mpassword = models.CharField(max_length=100, default='1')
    building = models.CharField(max_length=100, default='Default Building')


class Fix(models.Model):
    building = models.CharField(max_length=100, default='Default Building')
    room = models.CharField(max_length=100, default='Default Room')
    advise = models.TextField(default='Default Advice')


