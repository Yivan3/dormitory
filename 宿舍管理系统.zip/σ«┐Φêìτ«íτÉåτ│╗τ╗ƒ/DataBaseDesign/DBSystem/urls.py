from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path("login/", views.login_view),
    path('register/', views.register),
    path('theInfo/', views.theInfo),
    path('managePage/', views.managePage)
]
